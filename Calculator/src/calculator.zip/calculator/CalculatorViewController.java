package calculator;

/**
 * File Name:       Calculator.java
 * Author:          Mayank Khera
 * Student ID:		040912734
 * Course:          CST8221 - JavaApplicationProgramming
 * Lab Section: 
 * Assignment:      1, Part 1
 * Date:            October 15, 2019
 * Professor:       
 * Purpose:         This class is responsible for launching the application.
 * Class list:      Calculator                 
 */

import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import javax.swing.JLabel;
import javax.swing.ButtonGroup;
import javax.swing.Box;
import javax.swing.BorderFactory;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CalculatorViewController extends JPanel {
	private JTextField display1;// the calculator display1 field reference
	private JTextField display2;// the calculator display2 field reference
	private JLabel error;// the mode/error display label reference
	private JButton dotButton;// the decimal point (dot) button reference

	// private static final String[] keys = {"=", "C", "*", "+", "-", "/"};
	private static final String[] nums = { "A", "B", "C", "D", "E", "F", "7", "8", "9", "*", "4", "5", "6", "/", "1",
			"2", "3", "+", ".", "0", "\u00B1", "-" };

	public CalculatorViewController() {

		Controller controller = new Controller();

		JButton[] hexButtons = new JButton[6];

		JPanel keypad = new JPanel();
		JPanel keys = new JPanel();
		JPanel equals = new JPanel();
		JPanel clear = new JPanel();
		JPanel underDisplay = new JPanel();
		JPanel left = new JPanel();
		JPanel right = new JPanel();

		JPanel north = new JPanel();
		JPanel display = new JPanel();
		JButton backspace = new JButton();
	

		JCheckBox checkBox = new JCheckBox("Hex");

		JRadioButton singleJRadioButton = new JRadioButton(".0", false);
		JRadioButton doubleJRadioButton = new JRadioButton(".00", true);
		JRadioButton sciJRadioButton = new JRadioButton("Sci", false);
		JPanel radios = new JPanel();

		JPanel box = new JPanel();

		ButtonGroup group = new ButtonGroup();

		setLayout(new BorderLayout());
		setBorder(BorderFactory.createMatteBorder(5, 5, 5, 5, Color.BLACK));
		north.setLayout(new BorderLayout());

		backspace.setPreferredSize(new Dimension(52, 55));
		backspace.setBackground(Color.YELLOW);
		backspace.setOpaque(true);
		backspace.setBorder(BorderFactory.createMatteBorder(0, 5, 0, 1, Color.BLACK));
		backspace.setText("\u21da");
		backspace.setFont(new Font(backspace.getFont().getName(), Font.BOLD, 20));
		backspace.setToolTipText("Alt-B(Backspace)");
		backspace.setMnemonic('b');
		backspace.setActionCommand("\u21da");
		backspace.addActionListener(controller);

		error = new JLabel("F");
		error.setPreferredSize(new Dimension(52, 55));
		error.setOpaque(true);
		error.setBackground(Color.YELLOW);
		error.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 5, Color.BLACK));
		error.setHorizontalAlignment(JLabel.CENTER);
		error.setFont(new Font(error.getFont().getName(), error.getFont().getStyle(), 20));

		display.setLayout(new GridLayout(2, 0));
		display.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.BLACK));
		display1 = new JTextField();
		display1.setPreferredSize(new Dimension(14, 30));
		display1.setBackground(Color.WHITE);
		display1.setEditable(false);
		display1.setHorizontalAlignment(JTextField.RIGHT);
		display1.setBorder(BorderFactory.createEmptyBorder());

		display2 = new JTextField();
		display2.setPreferredSize(new Dimension(14, 30));
		display2.setBackground(Color.WHITE);
		display2.setEditable(false);
		display2.setHorizontalAlignment(JTextField.RIGHT);
		display2.setText("0.0");
		display2.setBorder(BorderFactory.createEmptyBorder());

		display.add(display1);
		display.add(display2);

		north.add(error, BorderLayout.WEST);
		north.add(display, BorderLayout.CENTER);
		north.add(backspace, BorderLayout.EAST);

		//mode.setLayout(new FlowLayout());
		
		checkBox.setBackground(Color.GREEN);
		checkBox.addActionListener(controller);
		singleJRadioButton.setBackground(Color.YELLOW);
		singleJRadioButton.addActionListener(controller);
		doubleJRadioButton.setBackground(Color.YELLOW);
		doubleJRadioButton.addActionListener(controller);
		sciJRadioButton.setBackground(Color.YELLOW);
		sciJRadioButton.addActionListener(controller);

		radios.setLayout(new GridLayout(1, 1, 5, 5));
		radios.setBackground(Color.YELLOW);
		radios.add(singleJRadioButton);
		radios.add(doubleJRadioButton);
		radios.add(sciJRadioButton);
		group.add(singleJRadioButton);
		group.add(doubleJRadioButton);
		group.add(sciJRadioButton);

		box.setLayout(new BorderLayout());
		box.setBackground(Color.BLACK);
		//box.setBackground(Color.BLACK);
		box.setBorder(BorderFactory.createMatteBorder(5, 1, 5, 1, Color.BLACK));
		//box.setBorder(BorderFactory.createMatteBorder(3, 3, 3, 3, Color.BLACK));
		box.add(checkBox, BorderLayout.WEST);
		box.add(radios, BorderLayout.EAST);

		


		
		north.add(box, BorderLayout.SOUTH);

		underDisplay.setLayout(new BorderLayout());
		keypad.setLayout(new BorderLayout());

		// keys.setLayout(new GridLayout(6,1));
		keys.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
		keys.setLayout(new GridLayout(6, 3, 3, 3));
		keys.setBackground(Color.WHITE);
		left.setLayout(new GridLayout(2,3 , 3, 3));
		left.setBackground(Color.BLACK);
		left.setBorder(BorderFactory.createEmptyBorder(0, 0, 3, 3));

		right.setLayout(new GridLayout(2, 3,3,3));
		right.setBackground(Color.BLACK);
		right.setBorder(BorderFactory.createEmptyBorder(0, 3, 3, 0));

		clear.setBackground(Color.BLACK);
		equals.setBackground(Color.BLACK);

		equals.setLayout(new GridLayout(1, 0));
		equals.setBorder(BorderFactory.createEmptyBorder(0, 0, 5, 0));
		clear.setLayout(new GridLayout(1, 0));
		clear.setBorder(BorderFactory.createEmptyBorder(1, 0, 0, 0));

		for (int i = 0; i < nums.length; i++) {
			if (nums[i].equals(".")) {
				dotButton = createButton(".", ".", Color.BLACK, Color.MAGENTA, new Controller());
				keys.add(dotButton);
			} else if (nums[i].equals("\u00B1")) {
				keys.add(createButton("\u00B1", "\u00B1", Color.BLACK, Color.MAGENTA, new Controller()));
			} else if (nums[i].equals("+") || nums[i].equals("-")) {
				right.add(createButton(nums[i], nums[i], Color.BLACK, Color.CYAN, new Controller()))
						.setPreferredSize(new Dimension(48, 55));
				;
			} else if (nums[i].equals("*") || nums[i].equals("/")) {
				left.add(createButton(nums[i], nums[i], Color.BLACK, Color.CYAN, new Controller()))
						.setPreferredSize(new Dimension(48, 55));
			} else if (nums[i].equals("A") || nums[i].equals("B") || nums[i].equals("C") || nums[i].equals("D")
					|| nums[i].equals("E") || nums[i].equals("F")) {
				hexButtons[i] = createButton(nums[i], nums[i], Color.GRAY, Color.BLUE, new Controller());
				keys.add(hexButtons[i]);
				hexButtons[i].setEnabled(false);
			} else {
				keys.add(createButton(nums[i], nums[i], Color.BLACK, Color.BLUE, new Controller()));
			}
		}

		clear.add(createButton("C", "C", Color.BLACK, Color.RED, new Controller()));
		equals.add(createButton("=", "=", Color.BLACK, Color.YELLOW, new Controller()));

		keypad.add(clear, BorderLayout.NORTH);
		keypad.add(keys, BorderLayout.CENTER);
		keypad.add(equals, BorderLayout.SOUTH);

		add(north, BorderLayout.NORTH);

		underDisplay.setBackground(Color.BLACK);
		underDisplay.add(left, BorderLayout.WEST);
		underDisplay.add(keypad, BorderLayout.CENTER);
		underDisplay.add(right, BorderLayout.EAST);

		add(underDisplay, BorderLayout.CENTER);

	}

	private JButton createButton(String text, String ac, Color fg, Color bg, ActionListener handler) {

		JButton retKey = new JButton(text);// create a button with text passed into the parameter

		retKey.setForeground(fg);// sets foreground color to fg
		retKey.setBackground(bg);// sets background color to bg

		if (ac != null)// if ac is null command need not be set
			retKey.setActionCommand(ac);// sets Action command to the passed parameter

		Font nFont = new Font(retKey.getName(), Font.PLAIN, 20);
		retKey.setFont(nFont);// sets the font to nFont(has font size 20 and doesn;t change the style or font)

		retKey.addActionListener(handler);// Registers the handler as an Action event listner for the button

		return retKey;// returns a reference to the created button
	}

	private class Controller implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent event) {
			display2.setText(event.getActionCommand());
		}
	}
}
